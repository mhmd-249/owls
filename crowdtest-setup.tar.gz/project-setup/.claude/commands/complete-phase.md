---
name: complete-phase
description: Complete the current phase. Run verification steps, update HANDOFF.md, and commit to git.
disable-model-invocation: true
---

# Complete Current Phase

1. Read `docs/HANDOFF.md` to determine the current phase
2. Read `docs/IMPLEMENTATION_GUIDE.md` to find the verification steps for the current phase
3. Run ALL verification steps listed for this phase
4. Report results: what passed, what failed
5. If all passed:
   - Update `docs/HANDOFF.md`: mark phase as Complete, add notes about what was built, any issues encountered
   - Run `git add -A && git commit -m "Complete Phase N: [description]"`
   - Tell the user to run /clear before starting the next phase
6. If any verification failed:
   - List what failed and suggest fixes
   - Do NOT mark the phase as complete

$ARGUMENTS
