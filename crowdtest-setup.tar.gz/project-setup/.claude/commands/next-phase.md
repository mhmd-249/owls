---
name: next-phase
description: Start the next development phase. Reads HANDOFF.md to determine current status, then loads the appropriate phase prompt from IMPLEMENTATION_GUIDE.md.
disable-model-invocation: true
---

# Start Next Phase

1. Read `docs/HANDOFF.md` to determine which phase was last completed
2. Read `CLAUDE.md` for project context
3. Read the CLAUDE.md in the relevant subdirectory (frontend/ or backend/) based on the next phase
4. Read `docs/IMPLEMENTATION_GUIDE.md` and find the prompt for the NEXT incomplete phase
5. Present the phase plan and ask for confirmation before starting
6. Begin implementing the phase

$ARGUMENTS
