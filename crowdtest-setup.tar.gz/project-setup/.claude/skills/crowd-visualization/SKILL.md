---
name: crowd-visualization
description: Skill for building the Minions-inspired crowd scene with animated SVG characters and thought bubbles. Use when working on the Testing Lab UI, character components, or crowd animations.
---

# Crowd Visualization — Character Design Guide

## Design Philosophy
Think Minions meets corporate focus group. Characters should be:
- Adorable but not childish
- Simple enough to render 30 on screen without performance issues
- Distinct enough that each feels like an individual

## Character Anatomy (SVG)
```
Total height: ~50px, width: ~35px

Body: <rect> with rx=12 for rounded corners
  - Random color from palette: ["#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7", "#DDA0DD", "#98D8C8", "#F7DC6F"]
  - Slight random height variation (45-55px) for crowd diversity

Eyes: Two <circle> r=5 white, with <circle> r=2.5 black pupils
  - Eyes positioned in upper third of body
  - Pupils can shift slightly (random offset 0-1px) for personality

Mouth: Simple <path> or <line>
  - Neutral: straight line
  - Happy: slight upward curve (when positive response)
  - Concerned: slight downward curve (when negative response)
```

## Crowd Layout Algorithm
```
1. Define a grid of ~6 columns × 5 rows
2. For each cell, place a character at the cell center
3. Add random jitter: ±15px horizontal, ±10px vertical
4. Add random scale variation: 0.85 - 1.15
5. Front row characters slightly larger (perspective)
6. Skip some cells randomly (2-3 gaps) so it doesn't look like a grid
```

## Animation Specs (Framer Motion)
```
Idle bobbing:
  y: [0, -3, 0], duration: 2s + random(0, 1s), repeat: Infinity

Thinking activation:
  scale: [1, 1.1, 1], duration: 0.3s
  body color briefly brightens

Thought bubble entrance:
  scale: [0, 1.1, 1], opacity: [0, 1]
  duration: 0.4s, ease: "backOut"

Thought bubble exit:
  scale: [1, 0], opacity: [1, 0]
  duration: 0.3s, delay: 5s
```

## Thought Bubble Design
```
- Rounded rectangle with 8px border-radius
- Max width: 180px
- 3 small circles (6px, 8px, 10px) forming "thought trail" from character head to bubble
- Text: 12px, max 2 lines, overflow: ellipsis
- Background color by sentiment:
  - Positive: bg-green-100, text-green-800, border-green-300
  - Neutral: bg-yellow-50, text-yellow-800, border-yellow-300  
  - Negative: bg-red-100, text-red-800, border-red-300
- Subtle shadow for depth
```

## Performance Notes
- Use CSS transforms for animations, not position/top/left
- Keep SVG simple — no gradients, filters, or complex paths
- Use will-change: transform on animated elements
- Batch DOM updates when multiple responses arrive simultaneously
- Consider using React.memo for Character components
