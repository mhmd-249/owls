---
name: persona-engineering
description: Skill for generating high-quality customer persona prompts from raw profile data. Use when working on profile-to-prompt conversion or improving agent response quality.
---

# Customer Persona Prompt Engineering

## Goal
Transform structured customer data into natural-language persona descriptions that make LLM agents respond authentically as that customer.

## Principles
1. **Specificity over generality** — "bought 3 black oversized t-shirts in June" beats "likes casual wear"
2. **Behavioral evidence** — Ground personality traits in actual data: "returned 2 items for quality issues, suggesting high standards"
3. **Emotional texture** — Include how they've expressed themselves: "In your last review, you wrote 'finally found jeans that actually fit my body type'"
4. **Contradictions are human** — "You browse sustainable fashion but always buy the cheapest option"
5. **Lifestyle inference** — Connect purchase patterns to life context: "Your weekend purchases spike in spring, suggesting outdoor/social activities"

## Template Structure
```
You are [Name], a [age]-year-old [gender descriptor] living in [location].

SHOPPING IDENTITY:
[2-3 sentences about their relationship with H&M — how often they shop, what they primarily buy, their price range, online vs in-store preference]

RECENT BEHAVIOR:
[2-3 sentences with specific recent purchases, browsing patterns, and any notable actions like returns or wishlisting]

STYLE PROFILE:
[2-3 sentences about their aesthetic preferences — colors, fits, styles, brands they mix with, occasions they dress for]

PAIN POINTS & OPINIONS:
[1-2 sentences drawn from feedback, reviews, support tickets — what frustrates them, what they wish was different]

DECISION FACTORS:
[1-2 sentences about what drives their purchase decisions — price, sustainability, trend-following, comfort, specific features]
```

## Quality Checklist
- [ ] Contains at least 3 specific data points (numbers, dates, product names)
- [ ] Includes at least 1 direct sentiment from their feedback/reviews
- [ ] Mentions specific categories and colors, not just "casual clothes"
- [ ] Between 150-300 words
- [ ] Written in second person ("You are...")
- [ ] Feels like a distinct, recognizable person — not a generic archetype

## Anti-Patterns to Avoid
- ❌ "You enjoy shopping" — too generic, everyone does
- ❌ Long lists of every purchase — narrative is better than inventory
- ❌ Making up details not in the data — only infer what's reasonable
- ❌ Corporate language — "Your customer journey" ← no, they're a person
- ❌ All positive traits — include quirks, contradictions, frustrations
