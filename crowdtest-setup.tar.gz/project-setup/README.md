# CrowdTest — Customer Digital Twin Simulation Engine

> Test product ideas with AI-powered digital twins of your real customers.

## What is this?

CrowdTest transforms your customer data into AI agents that respond to new product ideas exactly as your real customers would. Instead of expensive focus groups or slow surveys, get instant, data-grounded feedback from 200+ digital twin customers.

## How it works

1. **Upload customer data** → CrowdTest builds detailed persona profiles from purchase history, browsing behavior, feedback, and support interactions
2. **Describe your product idea** → "We're launching oversized graphic t-shirts with 90s designs at €24.99"  
3. **Watch 200 agents react** → Each digital twin responds based on their unique profile and preferences
4. **Get actionable insights** → Aggregated analysis with sentiment breakdown, segment analysis, and key themes

## Quick Start

```bash
# Install dependencies
make setup

# Configure API key
cp backend/.env.example backend/.env
# Edit backend/.env and add your ANTHROPIC_API_KEY

# Start both servers
make dev
```

- Frontend: http://localhost:3000
- Backend: http://localhost:8000

## Tech Stack

- **Frontend:** Next.js 14, TypeScript, Tailwind CSS, Framer Motion, Recharts
- **Backend:** Python FastAPI, anthropic SDK, SSE streaming
- **LLM:** Claude Sonnet (agents) + Claude Opus (aggregation)

## Demo

Built for a 2-day hackathon as a proof of concept using H&M customer data.
