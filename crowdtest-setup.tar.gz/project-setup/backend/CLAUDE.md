# Backend — FastAPI

## Stack
Python 3.11+, FastAPI, uvicorn, anthropic SDK, sse-starlette, pydantic

## Structure
```
backend/
├── app/
│   ├── main.py              # FastAPI app, CORS, mount routers
│   ├── config.py            # Settings from env vars
│   ├── routers/
│   │   ├── test.py          # POST /api/test, GET /api/test/{id}/stream, GET /api/test/{id}/results
│   │   └── profiles.py      # GET /api/profiles/stats
│   ├── services/
│   │   ├── profile_builder.py   # Raw data → persona prompt generation
│   │   ├── agent_runner.py      # Parallel Claude calls for all agents
│   │   ├── aggregator.py        # Collect responses → final insights via Opus
│   │   └── prompt_manager.py    # Load and format prompt templates
│   ├── models/
│   │   ├── schemas.py           # Pydantic request/response models
│   │   └── profile.py           # Customer profile data model
│   └── prompts/
│       ├── agent_persona.txt       # Template: persona system prompt
│       ├── agent_evaluation.txt    # Template: product evaluation user prompt
│       ├── aggregation_summary.txt # Template: executive summary generation
│       └── segment_analysis.txt    # Template: segment-based analysis
├── data/
│   ├── profiles/             # Raw H&M customer data (JSON)
│   └── processed/            # Generated persona prompts (cached)
├── tests/
│   └── test_agent_runner.py
├── requirements.txt
└── .env.example
```

## Key Design Patterns
- Use `asyncio.gather()` with `return_exceptions=True` for parallel agent calls
- Use `asyncio.Semaphore(50)` to limit concurrent API calls (avoid rate limits)
- Stream results via SSE using `sse-starlette` EventSourceResponse
- Store test sessions in-memory dict (no DB needed for MVP)
- Cache generated persona prompts in `data/processed/` to avoid regeneration

## Claude API Usage
```python
# Agent calls — use Sonnet for speed and cost
client = anthropic.AsyncAnthropic()
response = await client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=500,
    system=persona_prompt,  # Generated from customer profile
    messages=[{"role": "user", "content": product_description}]
)

# Aggregation — use Opus for quality
response = await client.messages.create(
    model="claude-opus-4-20250514",
    max_tokens=4000,
    system=aggregation_system_prompt,
    messages=[{"role": "user", "content": all_responses_combined}]
)
```

## SSE Response Format
```python
# Each agent response streamed as:
yield {
    "event": "agent_response",
    "data": json.dumps({
        "agent_id": "agent_042",
        "profile_name": "Sarah K.",
        "age": 28,
        "segment": "casual_weekend",
        "response": "I would love the wide t-shirt...",
        "sentiment": "positive",  # positive/neutral/negative
        "timestamp": "2024-01-15T14:30:00Z"
    })
}

# When all agents done:
yield {"event": "agents_complete", "data": json.dumps({"total": 200, "completed": 200})}

# Final insights:
yield {"event": "insights_ready", "data": json.dumps({"test_id": "..."})}
```

## Environment Variables
```
ANTHROPIC_API_KEY=sk-ant-...
MAX_CONCURRENT_AGENTS=50
AGENT_MODEL=claude-sonnet-4-20250514
AGGREGATION_MODEL=claude-opus-4-20250514
AGENT_MAX_TOKENS=500
```
