# Frontend — Next.js App

## Stack
Next.js 14 (App Router), TypeScript strict, Tailwind CSS, Framer Motion, Recharts

## Pages
- `/` — Testing Lab: chat sidebar + Minions crowd visualization (main page)
- `/insights/[testId]` — Insights Dashboard: executive summary, charts, drill-down

## Component Organization
```
src/
├── app/
│   ├── page.tsx              # Testing Lab
│   ├── insights/[testId]/page.tsx  # Insights Dashboard
│   └── layout.tsx            # Root layout with providers
├── components/
│   ├── lab/
│   │   ├── ChatSidebar.tsx        # Product description input
│   │   ├── CrowdScene.tsx         # Minions crowd container
│   │   ├── Character.tsx          # Single SVG character
│   │   ├── ThoughtBubble.tsx      # Speech bubble with response snippet
│   │   └── ProgressBar.tsx        # Agent response progress
│   ├── insights/
│   │   ├── ExecutiveSummary.tsx    # LLM-synthesized summary
│   │   ├── SentimentChart.tsx     # Positive/neutral/negative breakdown
│   │   ├── SegmentAnalysis.tsx    # By age, category, etc.
│   │   ├── ThemeExtractor.tsx     # Key themes from responses
│   │   └── ResponseDrillDown.tsx  # Individual agent responses
│   └── ui/
│       ├── Button.tsx
│       └── Card.tsx
├── lib/
│   ├── api.ts           # Backend API client + SSE handler
│   ├── types.ts         # Shared TypeScript interfaces
│   └── utils.ts         # Helpers (sentiment colors, etc.)
└── hooks/
    ├── useSSE.ts        # Server-Sent Events hook
    └── useTestSession.ts # Test state management
```

## SSE Connection Pattern
```typescript
// Use EventSource API for SSE from backend
const eventSource = new EventSource(`${API_URL}/api/test/${testId}/stream`);
eventSource.onmessage = (event) => {
  const data = JSON.parse(event.data);
  // data: { agent_id, profile_name, response, sentiment, segment }
};
```

## Character Design Rules
- Characters are simple SVG: rounded rectangle body + two circle eyes + optional simple mouth
- Max 30 characters visible on screen at once
- Characters arranged in a scattered "crowd" layout, not a grid
- Use Framer Motion for idle bobbing animation and thought bubble entrance
- Color-code thought bubbles: green (#22c55e) positive, yellow (#eab308) neutral, red (#ef4444) negative
- Thought bubble shows max 2 lines of response text (truncated)
- Characters don't need to match exact agent count — they represent the crowd

## Styling
- Dark theme background for the crowd scene (slate-900)
- Light sidebar for chat input
- Use Tailwind's color palette consistently
- Responsive but optimize for demo on a laptop screen (1440px wide)
